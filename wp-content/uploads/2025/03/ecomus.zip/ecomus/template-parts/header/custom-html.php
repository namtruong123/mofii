<?php
/**
 * Template part for displaying the custom HTML
 *
 * @package Ecomus
 */

?>

<div class="header-custom-html">
	<?php echo do_shortcode( \Ecomus\Helper::get_option('header_custom_html') ); ?>
</div>
