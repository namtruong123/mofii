<?php

/**
 * Template part for displaying the language
 *
 * @package Ecomus
 */

?>

<div id="topbar-slides" class="topbar-slides">
	<div class="topbar-slides__inner swiper">
		<div class="topbar-slides__wrapper swiper-wrapper columns-1">
			<?php echo \Ecomus\Header\Topbar::slides(); ?>
		</div>
	</div>
</div>