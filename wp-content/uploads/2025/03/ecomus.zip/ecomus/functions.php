<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Ecomus
 */

require_once get_template_directory() . '/inc/theme.php';

\Ecomus\Theme::instance()->init();